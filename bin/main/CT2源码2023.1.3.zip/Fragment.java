package creators;

import arc.scene.Group;

public abstract class Fragment {
    public abstract void build(Group parent);
}
