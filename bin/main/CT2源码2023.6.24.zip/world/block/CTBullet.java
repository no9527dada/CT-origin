package creators.world.block;


import arc.graphics.Color;
import mindustry.content.Fx;
import mindustry.entities.bullet.BulletType;
import mindustry.entities.bullet.FlakBulletType;
import mindustry.entities.bullet.LaserBulletType;

public class CTBullet {
        public static BulletType
        bawanglizi;
        public static void load() {
        bawanglizi = new FlakBulletType(8f, 1400f) {{
            var circleColor = Color.valueOf("e8ab19");
            sprite = "missile-large";
            reloadMultiplier=1;
            lifetime = 60f;
            width = 12f;
            height = 22f;

            hitSize = 7f;
            shootEffect = Fx.shootSmokeSquareBig;
            smokeEffect = Fx.shootSmokeDisperse;
            ammoMultiplier = 1;
            hitColor = backColor = trailColor = lightningColor = circleColor;
            frontColor = Color.white;
            trailWidth = 3f;
            trailLength = 12;
            hitEffect = despawnEffect = Fx.hitBulletColor;
            //buildingDamageMultiplier = 0.3f;

            trailEffect = Fx.colorSpark;
            trailRotation = true;
            trailInterval = 3f;
            lightning = 1;
            lightningCone = 15f;
            lightningLength = 20;
            lightningLengthRand = 30;
            lightningDamage = 800f;

            homingPower = 0.17f;
            homingDelay = 19f;
            homingRange = 160f;

            explodeRange = 160f;
            explodeDelay = 0f;

            flakInterval = 20f;
            despawnShake = 3f;
            fragBullets = 1;
            fragBullet = new LaserBulletType(7500f) {{
                colors = new Color[]{circleColor.cpy().a(0.4f), circleColor, Color.white};
                //buildingDamageMultiplier = 0.25f;
                width = 40f;
                hitEffect = Fx.hitLancer;
                sideAngle = 175f;
                sideWidth = 1f;
                sideLength = 40f;
                lifetime = 22f;
                drawSize = 400f;
                length = 180f*2;
                pierce= true;
               // pierceCap = 2;
            }};

            fragSpread = fragRandomSpread = 0f;

            splashDamage = 0f;
            hitEffect = Fx.hitSquaresColor;
            collidesGround = true;
        }};
    }
}
