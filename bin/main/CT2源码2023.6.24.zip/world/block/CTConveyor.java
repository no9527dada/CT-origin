package creators.world.block;

import mindustry.content.Items;
import mindustry.type.Category;
import mindustry.world.Block;
import mindustry.world.blocks.distribution.*;

import static mindustry.type.ItemStack.with;

public class CTConveyor {
    public static Block
    csdq0,lianjieqi2,  conveyor1,conveyor12,conveyor2,conveyor21
            ;

    public static void load() {
        csdq0 = new ItemBridge("csqd0") {{}};
        lianjieqi2 = new Junction("lianjieqi2") {{}};

        conveyor1 = new Conveyor("1-conveyor") {{}
            @Override
            public void init() {
                super.init();

                junctionReplacement = CTBlocks.junction;
                bridgeReplacement = csdq0;
            }
        };
        conveyor12 = new ArmoredConveyor("1-conveyor1") {{}
            @Override
            public void init() {
                super.init();

                junctionReplacement = CTBlocks.junction;
                bridgeReplacement = csdq0;
            }
        };
        conveyor2 = new Conveyor("2-conveyor") {{}
            @Override
            public void init() {
                super.init();

                junctionReplacement = lianjieqi2;
                bridgeReplacement = csdq0;
            }
        };
        conveyor21 = new ArmoredConveyor("2-conveyor1") {{}
            @Override
            public void init() {
                super.init();

                junctionReplacement = lianjieqi2;
                bridgeReplacement = csdq0;
            }
        };














    }
}

